#!/bin/bash
user=$(whoami)

# ###########################################
# Create directories for CDM Connect
# ###########################################
echo "Creating directories for CDM Connect"
# Create the base directories if they don't exist
if [ ! -d "/home/$user/cdmconnect" ]; then
    mkdir -p /home/$user/cdmconnect
fi
if [ ! -d "/home/$user/cdmconnect" ]; then
    mkdir -p /home/$user/rabbitmq
fi

# Create the sub-directories if they don't exist
if [ ! -d "/home/$user/cdmconnect/weblog" ]; then
    mkdir -p /home/$user/cdmconnect/weblog
fi
if [ ! -d "/home/$user/cdmconnect/applog" ]; then
    mkdir -p /home/$user/cdmconnect/applog
fi
if [ ! -d "/home/$user/cdmconnect/certs" ]; then
    mkdir -p /home/$user/cdmconnect/certs
fi
if [ ! -d "/home/$user/cdmconnect/plant_focus_definitions" ]; then
    mkdir -p /home/$user/cdmconnect/plant_focus_definitions
fi
if [ ! -d "/home/$user/cdmconnect/source_bol" ]; then
    mkdir -p /home/$user/cdmconnect/source_bol
fi
if [ ! -d "/home/$user/cdmconnect/destination_bol" ]; then
    mkdir -p /home/$user/cdmconnect/destination_bol
fi
if [ ! -d "/home/$user/rabbitmq/data" ]; then
    mkdir -p /home/$user/rabbitmq/data
fi
if [ ! -d "/home/$user/rabbitmq/config" ]; then
    mkdir -p /home/$user/rabbitmq/config
fi


# ###########################################
# Update ownership & permissions
# ###########################################
echo "Updating ownership & permissions"
# take ownership of all folders we want to operate on
sudo chown :$user $(find /home/$user/cdmconnect -maxdepth 1 -type d)
sudo chown :$user $(find /home/$user/rabbitmq -maxdepth 2)

# Change the permissions of all folders we want to operate on
sudo chmod ug+rwx $(find /home/$user/cdmconnect -maxdepth 1 -type d)
sudo chmod ug+rwx $(find /home/$user/rabbitmq -maxdepth 1 -type d)

# change permissions of all rabbitmq configuration files if they exist 
sudo find /home/$user/rabbitmq/config/ -type f -exec chown :$user {} +
sudo find /home/$user/rabbitmq/config/ -type f -exec chmod g+rw {} +

# change permissions of all certs if they exist
sudo find /home/$user/cdmconnect/certs/ -type f -exec chown :$user {} +
sudo find /home/$user/cdmconnect/certs/ -type f -exec chmod g+rw {} +


# ###########################################
# Copy RabbitMQ configuration files
# ###########################################
echo "Copying RabbitMQ configuration files"
cp -u rabbitmq/* /home/$user/rabbitmq/config/


# ###########################################
# Copy certificates
# ###########################################
echo "Copying certificates"
cp -u certs/* /home/$user/cdmconnect/certs/


# ###########################################
# Update YAML volume paths
# ###########################################
echo "Updating YAML volume paths"
sed -i "s/\/home\/pscl/\/home\/$user/" docker-compose.yml
